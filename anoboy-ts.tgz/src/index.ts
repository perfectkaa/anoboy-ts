import { AnoboyClient } from './client';
import { parseListing, ListingResult } from './parsers/listing';
import { parseSchedule, ScheduleResult } from './parsers/schedule';
import { parseAnimeDetail } from './parsers/detail';
import { parseEpisode, EpisodeDetail } from './parsers/episode';
import {
  AnimeItem,
  AnimeDetail,
  EpisodeReference,
  EpisodeDetail as IEpisodeDetail,
  StreamingServer,
  ScheduleItem,
  PaginationOptions,
  RequestOptions,
  AnoboyOptions,
  AnoboyError,
} from './types';
import {
  NetworkError,
  TimeoutError,
  HttpError,
  ParseError,
  InvalidUrlError,
  NotFoundError,
  RateLimitError,
} from './errors';

export {
  AnimeItem,
  AnimeDetail,
  EpisodeReference,
  IEpisodeDetail,
  StreamingServer,
  ScheduleItem,
  PaginationOptions,
  RequestOptions,
  AnoboyOptions,
  AnoboyError,
  NetworkError,
  TimeoutError,
  HttpError,
  ParseError,
  InvalidUrlError,
  NotFoundError,
  RateLimitError,
};

const DEFAULT_BASE_URL = 'https://anoboy.quest/';

export class Anoboy {
  private client: AnoboyClient;

  constructor(options: AnoboyOptions = {}) {
    this.client = new AnoboyClient(options);
  }

  private async fetchHtml(url: string, options: RequestOptions = {}): Promise<string> {
    try {
      return await this.client.get(url, options);
    } catch (error) {
      if (error instanceof NetworkError) throw error;
      if (error instanceof TimeoutError) throw error;
      if (error instanceof HttpError) throw error;
      if (error instanceof RateLimitError) throw error;
      throw error;
    }
  }

  async getLatest(options: PaginationOptions & RequestOptions = {}): Promise<ListingResult> {
    const url = new URL(DEFAULT_BASE_URL).href;
    const html = await this.fetchHtml(url, options);
    return parseListing(html, DEFAULT_BASE_URL);
  }

  async getSchedule(options: RequestOptions & { day?: string } = {}): Promise<ScheduleResult> {
    const url = new URL('schedule', DEFAULT_BASE_URL).href;
    const html = await this.fetchHtml(url, options);
    return parseSchedule(html, DEFAULT_BASE_URL, options.day);
  }

  async getAnimeList(options: PaginationOptions & RequestOptions = {}): Promise<ListingResult> {
    const url = new URL('anime-list', DEFAULT_BASE_URL).href;
    const html = await this.fetchHtml(url, options);
    return parseListing(html, DEFAULT_BASE_URL);
  }

  async getDonghuaList(options: PaginationOptions & RequestOptions = {}): Promise<ListingResult> {
    const url = new URL('donghua-list', DEFAULT_BASE_URL).href;
    const html = await this.fetchHtml(url, options);
    return parseListing(html, DEFAULT_BASE_URL);
  }

  async getMovies(options: PaginationOptions & RequestOptions = {}): Promise<ListingResult> {
    const url = new URL('movie-list', DEFAULT_BASE_URL).href;
    const html = await this.fetchHtml(url, options);
    return parseListing(html, DEFAULT_BASE_URL);
  }

  async getTokusatsu(options: PaginationOptions & RequestOptions = {}): Promise<ListingResult> {
    const url = new URL('tokusatsu-list', DEFAULT_BASE_URL).href;
    const html = await this.fetchHtml(url, options);
    return parseListing(html, DEFAULT_BASE_URL);
  }

  async getLiveAction(options: PaginationOptions & RequestOptions = {}): Promise<ListingResult> {
    const url = new URL('live-action-list', DEFAULT_BASE_URL).href;
    const html = await this.fetchHtml(url, options);
    return parseListing(html, DEFAULT_BASE_URL);
  }

  async getGhibli(options: PaginationOptions & RequestOptions = {}): Promise<ListingResult> {
    const url = new URL('ghibli-list', DEFAULT_BASE_URL).href;
    const html = await this.fetchHtml(url, options);
    return parseListing(html, DEFAULT_BASE_URL);
  }

  async getAnimeDetail(url: string): Promise<AnimeDetail> {
    const html = await this.fetchHtml(url);
    return parseAnimeDetail(html, url);
  }

  async getEpisode(url: string): Promise<IEpisodeDetail> {
    const html = await this.fetchHtml(url);
    return parseEpisode(html, url);
  }

  async search(query: string, options: PaginationOptions & RequestOptions = {}): Promise<ListingResult> {
    const searchUrl = new URL('search', DEFAULT_BASE_URL);
    searchUrl.searchParams.set('s', query);
    const html = await this.fetchHtml(searchUrl.href, options);
    return parseListing(html, DEFAULT_BASE_URL);
  }

  async getPage(url: string, options: RequestOptions = {}): Promise<ListingResult> {
    const html = await this.fetchHtml(url, options);
    return parseListing(html, url);
  }

  async getRawHtml(url: string, options: RequestOptions = {}): Promise<string> {
    return this.fetchHtml(url, options);
  }

  clearCache(): void {
    this.client.clearCache();
  }
}

export default Anoboy;