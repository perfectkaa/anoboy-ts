import * as cheerio from 'cheerio';
import { EpisodeDetail, StreamingServer } from '../types';
import { ensureAbsoluteUrl } from '../utils/url';

export interface EpisodeParseOptions {
  url: string;
}

export function parseEpisode(html: string, baseUrl: string): EpisodeDetail {
  const $ = cheerio.load(html);

  const titleEl = $('h1.post-title').first();
  const title = titleEl.text().trim() || null;

  let playerUrl: string | null = null;
  const iframe = $('#mediaplayer');
  if (iframe.length) {
    const src = iframe.attr('src');
    if (src) {
      playerUrl = ensureAbsoluteUrl(baseUrl, src);
    }
  }

  const servers: StreamingServer[] = [];

  $('.vmiror').each((_, container) => {
    const $container = $(container);
    const name = $container.text().trim() || 'Unknown Server';

    $container.find('a[data-video]').each((_, link) => {
      const $link = $(link);
      const videoUrl = $link.attr('data-video') || '';
      if (!videoUrl) return;

      const resolvedUrl = videoUrl.startsWith('http')
        ? videoUrl
        : ensureAbsoluteUrl(baseUrl, videoUrl);

      const linkText = $link.text().trim();
      const quality = linkText || $link.attr('data-quality') || null;

      servers.push({
        name,
        quality,
        url: resolvedUrl,
        type: 'embed',
      });
    });
  });

  if (servers.length === 0) {
    $('a[data-video]').each((_, link) => {
      const $link = $(link);
      const videoUrl = $link.attr('data-video') || '';
      if (!videoUrl) return;

      const resolvedUrl = videoUrl.startsWith('http')
        ? videoUrl
        : ensureAbsoluteUrl(baseUrl, videoUrl);

      const linkText = $link.text().trim();
      const quality = linkText || $link.attr('data-quality') || null;
      const name = $link.closest('.vmiror').text().trim() || 'Unknown Server';

      servers.push({
        name,
        quality,
        url: resolvedUrl,
        type: 'embed',
      });
    });
  }

  return {
    url: baseUrl,
    title,
    playerUrl,
    servers,
  };
}