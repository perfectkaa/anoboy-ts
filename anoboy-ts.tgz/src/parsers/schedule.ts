import * as cheerio from 'cheerio';
import { ScheduleItem } from '../types';
import { ensureAbsoluteUrl } from '../utils/url';

export interface ScheduleResult {
  items: ScheduleItem[];
  days: string[];
}

export function parseSchedule(html: string, baseUrl: string, dayFilter?: string): ScheduleResult {
  const $ = cheerio.load(html);
  const items: ScheduleItem[] = [];
  const days: string[] = [];

  $('table tbody tr').each((_, row) => {
    const $row = $(row);
    const link = $row.find('td:nth-child(1) a').first();
    const dayText = $row.find('td:nth-child(2)').first().text().trim();
    const timeText = $row.find('td:nth-child(3)').first().text().trim();

    const title = link.text().trim();
    const urlRaw = link.attr('href') || null;
    const url = urlRaw ? ensureAbsoluteUrl(baseUrl, urlRaw) : null;

    const day = dayText || null;
    const time = timeText || null;

    if (!days.includes(day)) {
      if (day) days.push(day);
    }

    if (title) {
      if (dayFilter && day && day.toLowerCase() !== dayFilter.toLowerCase()) {
        return;
      }
      items.push({ title, day, time, url });
    }
  });

  if (items.length === 0) {
    const containers = $('.amv');
    containers.each((_, el) => {
      const $el = $(el);
      const link = $el.find('a[rel="bookmark"]').first();
      const timeEl = $el.find('.jamup').first();

      const title = link.attr('title')?.trim() || link.text().trim() || '';
      const urlRaw = link.attr('href') || '';
      const url = urlRaw ? ensureAbsoluteUrl(baseUrl, urlRaw) : null;
      const updatedAt = timeEl.text().trim() || null;

      if (title && url) {
        if (dayFilter && updatedAt) {
          const dayPart = updatedAt.split(' ')[0];
          if (dayPart && dayPart.toLowerCase() !== dayFilter.toLowerCase()) {
            return;
          }
        }
        items.push({ title, day: updatedAt ? updatedAt : null, time: null, url });
        if (updatedAt && !days.includes(updatedAt)) days.push(updatedAt);
      }
    });
  }

  return { items, days };
}