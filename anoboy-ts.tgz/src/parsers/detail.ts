import * as cheerio from 'cheerio';
import { AnimeDetail, EpisodeReference } from '../types';
import { ensureAbsoluteUrl } from '../utils/url';

const normalizeNumber = (value: string): number | null => {
  const trimmed = value.trim();
  if (!trimmed || trimmed === '???' || trimmed === 'N/A' || trimmed === 'n/a') {
    return null;
  }
  const num = parseFloat(trimmed);
  return isNaN(num) ? null : num;
};

const normalizeText = (value: string): string | null => {
  const trimmed = value.trim();
  if (!trimmed || trimmed === '???' || trimmed === 'N/A' || trimmed === 'n/a') {
    return null;
  }
  return trimmed;
};

export function parseAnimeDetail(html: string, url: string): AnimeDetail {
  const $ = cheerio.load(html);

  let title = normalizeText($('h1.post-title').first().text()) || 
              normalizeText($('title').first().text()) || 
              'Unknown Title';

  const img = $('.unduhan img, .wp-post-image').first();
  const image = img.attr('src') ? ensureAbsoluteUrl(url, img.attr('src') as string) : null;

  const descriptionContainer = $('.unduhan');
  const description = descriptionContainer.find('p').first().text().trim() || null;

  const metadata: Record<string, string> = {};

  $('.unduhan table tr').each((_, row) => {
    const cells = $(row).find('td');
    const label = cells.first().text().trim().toLowerCase();
    const value = cells.last().text().trim();
    if (label && value) {
      metadata[label] = value;
    }
  });

  const totalEpisodes = normalizeNumber(metadata['episodes'] || metadata['episode'] || '');

  const studio = normalizeText(metadata['studio'] || '');
  const sourceField = normalizeText(metadata['source'] || '');

  let duration: string | null = null;
  const durasiEl = $('#durasi');
  if (durasiEl.length) {
    duration = normalizeText(durasiEl.text());
  } else {
    duration = normalizeText(metadata['durasi'] || metadata['duration'] || '');
  }

  let genres: string[] = [];
  const genreEl = $('#genre');
  if (genreEl.length) {
    const genreText = genreEl.text().trim();
    genres = genreText ? genreText.split(',').map((g) => g.trim()).filter(Boolean) : [];
  } else {
    const genreMetadata = normalizeText(metadata['genre'] || metadata['genres'] || '');
    genres = genreMetadata ? genreMetadata.split(',').map((g) => g.trim()).filter(Boolean) : [];
  }

  let score: number | null = null;
  const scoreEl = $('#score');
  if (scoreEl.length) {
    const scoreText = scoreEl.text().trim().replace(/\/10/, '');
    score = normalizeNumber(scoreText);
  } else {
    score = normalizeNumber(metadata['score'] || '');
  }

  const episodeList: EpisodeReference[] = [];
  $('.singlelink .lcp_catlist li a').each((_, el) => {
    const $el = $(el);
    const title = $el.text().trim() || '';
    const href = $el.attr('href') || '';
    if (title && href) {
      const episodeNumber = extractEpisodeNumber(title);
      episodeList.push({
        title,
        url: ensureAbsoluteUrl(url, href),
        episodeNumber,
      });
    }
  });

  return {
    title,
    url,
    image,
    description,
    totalEpisodes,
    studio,
    source: sourceField,
    duration,
    genres,
    score,
    episodeList,
  };
}

function extractEpisodeNumber(title: string): number | null {
  const match = title.match(/Episode\s*(\d+)/i) || title.match(/\s(\d+)$/);
  if (match) {
    const num = parseInt(match[1]);
    return isNaN(num) ? null : num;
  }
  return null;
}